import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
      int bankAccount = 10000;
      int withdrawalLimit = 1000;
      int maxOperationNum = 5;
      int operationsNumber = 0;
      Scanner scanner = new Scanner(System.in);


        do {
            System.out.println("Введите необходимую сумму");
            int withdrawalSumm = scanner.nextInt();
            if (withdrawalSumm<=withdrawalLimit){
                System.out.println("Возьмите вашу сумму " + withdrawalSumm);
                System.out.println("На вашем счету осталось " + (bankAccount - withdrawalSumm));
                System.out.println("Вы можете проводить ещё " + (maxOperationNum--) + " раз");
                operationsNumber++;
            } else if (withdrawalSumm>withdrawalLimit) {
                System.out.println("Превышение лимита , попробуйте ещё раз ");
            }
        }while (operationsNumber>maxOperationNum);
    }
            }




