import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
  public static void main(String[] args) {
    int[] ints = new int[10];

    for (int i = 0; i < ints.length; i++) {
      ints[i] =(int) (Math.random()*10)+10;
    }
    System.out.println(Arrays.toString(ints));
    boolean grow = true;

    for (int i = 0;i< ints.length;i++){
      if (ints[i]<ints[i-1]){
        grow = false;
        break;
      }
      if (grow){
        System.out.println("Массив ростёт");
      }else {
        System.out.println("Массив не верен");
      }
    }
  }
}

            









