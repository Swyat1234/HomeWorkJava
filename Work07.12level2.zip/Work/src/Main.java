import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.println("How Many Rows You Want In Your Pyramid?");

        int levelNumber = scanner.nextInt();

        int lineCount = 1;

        System.out.println("Here Is Your Pyramid");

        for (int i = levelNumber; i > 0; i--)
        {
            for (int j = 1; j <= i; j++)
            {
                System.out.print(" ");
            }

            for (int j = 1; j <= lineCount; j++)
            {
                System.out.print("& ");
            }

            System.out.println();
            lineCount++;
        }
    }
}




