import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int []nums = new int[] {124,54,65,434,87,432,123,543,231,547,55,421};
        boolean ready = false;

        while (!ready) {
            ready = true;

            for (int i = 1;i < nums.length;i++) {
                if (nums[i] < nums[i - 1]) {
                    int check = nums[i];
                    nums[i] = nums[i - 1];
                    nums[i - 1] = check;
                    ready = false;

                }
            }
            System.out.println(Arrays.toString(nums));
        }
    }
    }



            









